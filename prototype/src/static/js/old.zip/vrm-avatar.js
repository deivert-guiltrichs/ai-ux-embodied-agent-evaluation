import * as THREE from "https://esm.sh/three@0.170.0";
import { GLTFLoader } from "https://esm.sh/three@0.170.0/examples/jsm/loaders/GLTFLoader.js";
import { VRMLoaderPlugin, VRMUtils } from "https://esm.sh/@pixiv/three-vrm@3.5.3?deps=three@0.170.0";

let scene;
let camera;
let renderer;
let currentVrm = null;
let clock;
let isTalking = false;
let mouthTimer = 0;
let blinkTimer = 0;
let nextBlink = 2 + Math.random() * 3;
let animationFrameId = null;
let initialized = false;
let loadingPromise = null;

const AVATAR_URL = "/static/assets/avatar.vrm";

function getCanvas() {
    return document.getElementById("vrmCanvas");
}

function getLoadingElement() {
    return document.getElementById("vrmLoading");
}

function showLoadingMessage(message) {
    const loading = getLoadingElement();

    if (loading) {
        loading.textContent = message;
        loading.classList.remove("hidden");
    }
}

function hideLoadingMessage() {
    const loading = getLoadingElement();

    if (loading) {
        loading.classList.add("hidden");
    }
}



function resizeRenderer() {
    const canvas = getCanvas();

    if (!canvas || !renderer || !camera) {
        return;
    }

    const container = canvas.parentElement;
    const width = container.clientWidth || 420;
    const height = container.clientHeight || 520;

    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
}

function setupScene() {
    const canvas = getCanvas();

    if (!canvas) {
        throw new Error("No se encontró el canvas #vrmCanvas.");
    }

    scene = new THREE.Scene();
    clock = new THREE.Clock();

    camera = new THREE.PerspectiveCamera(30, 1, 0.1, 20);
    camera.position.set(0, 1.10, 3.65);

    renderer = new THREE.WebGLRenderer({
        canvas,
        alpha: true,
        antialias: true
    });

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.65);
    keyLight.position.set(1.5, 2.2, 2.8);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x9ec5ff, 0.75);
    fillLight.position.set(-1.6, 1.4, 1.6);
    scene.add(fillLight);

    resizeRenderer();
    window.addEventListener("resize", resizeRenderer);
}

function applyRelaxedArmPose(vrm) {
    if (!vrm || !vrm.humanoid) {
        return;
    }

    const leftUpperArm = vrm.humanoid.getNormalizedBoneNode("leftUpperArm");
    const rightUpperArm = vrm.humanoid.getNormalizedBoneNode("rightUpperArm");
    const leftLowerArm = vrm.humanoid.getNormalizedBoneNode("leftLowerArm");
    const rightLowerArm = vrm.humanoid.getNormalizedBoneNode("rightLowerArm");

    if (leftUpperArm) {
        leftUpperArm.rotation.z = 1.15;
        leftUpperArm.rotation.x = 0.15;
    }

    if (rightUpperArm) {
        rightUpperArm.rotation.z = -1.15;
        rightUpperArm.rotation.x = 0.15;
    }

    if (leftLowerArm) {
        leftLowerArm.rotation.z = 0.25;
    }

    if (rightLowerArm) {
        rightLowerArm.rotation.z = -0.25;
    }
}

function loadVrm() {
    return new Promise((resolve, reject) => {
        showLoadingMessage("Cargando avatar 3D...");

        const loader = new GLTFLoader();

        loader.register((parser) => {
            return new VRMLoaderPlugin(parser);
        });

        loader.load(
            AVATAR_URL,
            (gltf) => {
                try {
                    const vrm = gltf.userData.vrm;

                    if (!vrm) {
                        throw new Error("El archivo se cargó, pero no contiene datos VRM válidos.");
                    }

                    VRMUtils.removeUnnecessaryVertices(gltf.scene);
                    VRMUtils.removeUnnecessaryJoints(gltf.scene);

                    currentVrm = vrm;
                    scene.add(vrm.scene);

                    // Si el modelo se ve de espaldas, cambie Math.PI por 0.
                    vrm.scene.rotation.y = Math.PI;
                    vrm.scene.position.set(0, 0.25, 0);

                    applyRelaxedArmPose(vrm);

                    hideLoadingMessage();
                    animate();

                    console.log("Avatar VRM cargado correctamente:", currentVrm);
                    resolve(currentVrm);
                } catch (error) {
                    showLoadingMessage("No se pudo preparar el avatar VRM.");
                    reject(error);
                }
            },
            (progress) => {
                if (progress.total > 0) {
                    const percent = Math.round((progress.loaded / progress.total) * 100);
                    showLoadingMessage(`Cargando avatar 3D... ${percent}%`);
                }
            },
            (error) => {
                showLoadingMessage("No se pudo cargar el avatar VRM. Revise la consola del navegador.");
                reject(error);
            }
        );
    });
}

function animate() {
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
    }

    const renderLoop = () => {
        animationFrameId = requestAnimationFrame(renderLoop);

        const delta = clock.getDelta();
        const elapsed = clock.elapsedTime;

        if (currentVrm) {
            currentVrm.update(delta);

            // Movimiento corporal sutil para evitar avatar estático.
            currentVrm.scene.rotation.y = Math.PI + Math.sin(elapsed * 0.7) * 0.045;

            // Movimiento leve de respiración / presencia.
            currentVrm.scene.position.y += Math.sin(elapsed * 1.4) * 0.0008;

            // Movimiento leve de cabeza y torso.
            const head = currentVrm.humanoid?.getNormalizedBoneNode("head");
            const neck = currentVrm.humanoid?.getNormalizedBoneNode("neck");
            const chest = currentVrm.humanoid?.getNormalizedBoneNode("chest");
            const spine = currentVrm.humanoid?.getNormalizedBoneNode("spine");

            if (head) {
                head.rotation.y = Math.sin(elapsed * 0.8) * 0.035;
                head.rotation.x = Math.sin(elapsed * 0.6) * 0.018;
            }

            if (neck) {
                neck.rotation.y = Math.sin(elapsed * 0.7) * 0.018;
            }

            if (chest) {
                chest.rotation.y = Math.sin(elapsed * 0.45) * 0.018;
            }

            if (spine) {
                spine.rotation.y = Math.sin(elapsed * 0.35) * 0.012;
            }

            // Parpadeo automático.
            blinkTimer += delta;

            if (blinkTimer > nextBlink) {
                setBlink(1.0);

                window.setTimeout(() => {
                    setBlink(0.0);
                }, 120);

                blinkTimer = 0;
                nextBlink = 2 + Math.random() * 4;
            }

            // Lip-sync básico: abre/cierra la boca mientras habla.
            if (isTalking) {
                mouthTimer += delta;
                const openness = 0.18 + Math.abs(Math.sin(mouthTimer * 16)) * 0.72;
                setMouthOpen(openness);
            } else {
                setMouthOpen(0);
            }
        }

        renderer.render(scene, camera);
    };

    renderLoop();
}

async function initVrmAvatar() {
    if (initialized) {
        return currentVrm;
    }

    if (loadingPromise) {
        return loadingPromise;
    }

    loadingPromise = (async () => {
        setupScene();
        const vrm = await loadVrm();
        initialized = true;
        return vrm;
    })();

    return loadingPromise;
}

function setExpression(name, value) {
    if (!currentVrm || !currentVrm.expressionManager) {
        return false;
    }

    try {
        currentVrm.expressionManager.setValue(name, value);
        return true;
    } catch (error) {
        return false;
    }
}

function setAnyExpression(names, value) {
    let applied = false;

    names.forEach((name) => {
        const ok = setExpression(name, value);
        if (ok) {
            applied = true;
        }
    });

    return applied;
}

function applyMorphTargetByName(possibleNames, value) {
    if (!currentVrm || !currentVrm.scene) {
        return false;
    }

    let applied = false;

    currentVrm.scene.traverse((object) => {
        if (!object.isMesh || !object.morphTargetDictionary || !object.morphTargetInfluences) {
            return;
        }

        possibleNames.forEach((name) => {
            const index = object.morphTargetDictionary[name];

            if (index !== undefined) {
                object.morphTargetInfluences[index] = value;
                applied = true;
            }
        });
    });

    return applied;
}

function setMouthOpen(value) {
    const mouthValue = Math.max(0, Math.min(1, value));

    // Nombres comunes en VRM 1.0, VRM 0.x y algunos modelos exportados desde VRoid.
    const expressionApplied = setAnyExpression(
        [
            "aa",
            "Aa",
            "A",
            "a",
            "oh",
            "Oh",
            "O",
            "o",
            "mouthOpen",
            "MouthOpen"
        ],
        mouthValue
    );

    // Fallback directo sobre morph targets por si el ExpressionManager no mapea la boca.
    const morphApplied = applyMorphTargetByName(
        [
            "aa",
            "Aa",
            "A",
            "a",
            "あ",
            "mouthOpen",
            "MouthOpen",
            "Fcl_MTH_A",
            "Fcl_MTH_Angry",
            "vrc.v_aa"
        ],
        mouthValue
    );

    if (!expressionApplied && !morphApplied && mouthValue > 0) {
        console.warn("No se encontró una expresión o morph target de boca compatible en este VRM.");
    }
}

function setBlink(value) {
    const blinkValue = Math.max(0, Math.min(1, value));

    setAnyExpression(
        [
            "blink",
            "Blink",
            "blinkLeft",
            "blinkRight",
            "Blink_L",
            "Blink_R"
        ],
        blinkValue
    );

    applyMorphTargetByName(
        [
            "blink",
            "Blink",
            "Blink_L",
            "Blink_R",
            "Fcl_EYE_Close",
            "vrc.blink_left",
            "vrc.blink_right"
        ],
        blinkValue
    );
}

function startTalking() {
    isTalking = true;
    mouthTimer = 0;

    // Apertura inicial inmediata para confirmar visualmente que responde.
    setMouthOpen(0.65);
}

function stopTalking() {
    isTalking = false;
    setMouthOpen(0);
}

function disposeVrmAvatar() {
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
    }
}

window.vrmAvatar = {
    init: initVrmAvatar,

    startTalking: function () {
        console.log("VRM startTalking()");
        startTalking();
        return "startTalking ejecutado";
    },

    stopTalking: function () {
        console.log("VRM stopTalking()");
        stopTalking();
        return "stopTalking ejecutado";
    },

    testTalk: function () {
        console.log("VRM testTalk() iniciado");
        startTalking();

        setTimeout(() => {
            stopTalking();
            console.log("VRM testTalk() finalizado");
        }, 3000);

        return "testTalk ejecutado por 3 segundos";
    },

    forceMouth: function (value = 1) {
        console.log("VRM forceMouth()", value);
        setMouthOpen(value);
        return `forceMouth aplicado con valor ${value}`;
    },

    debug: function () {
        console.log("currentVrm:", currentVrm);
        console.log("expressionManager:", currentVrm?.expressionManager);

        if (currentVrm?.scene) {
            const morphTargets = [];

            currentVrm.scene.traverse((object) => {
                if (object.isMesh && object.morphTargetDictionary) {
                    morphTargets.push({
                        name: object.name,
                        morphs: Object.keys(object.morphTargetDictionary)
                    });
                }
            });

            console.log("Morph targets encontrados:", morphTargets);
            return morphTargets;
        }

        return [];
    },

    dispose: disposeVrmAvatar
};

console.log("VRM avatar controller exposed:", window.vrmAvatar);
